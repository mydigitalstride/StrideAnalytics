<?php
/**
 * Schema Output Engine (Phase 5).
 *
 * Fires on wp_head and outputs JSON-LD blocks.
 * Also outputs SEO meta tags (title override, meta description, OG, Twitter, robots).
 *
 * @package ECHoS_SEO_Analytics
 */

defined( 'ABSPATH' ) || exit;

class ECHS_Schema_Output {

	public static function init(): void {
		add_action( 'wp_head', [ __CLASS__, 'output_seo_meta' ],    1 );
		add_action( 'wp_head', [ __CLASS__, 'output_schema' ],      5 );
		add_filter( 'pre_get_document_title', [ __CLASS__, 'filter_title' ] );
	}

	// ------------------------------------------------------------------
	// Helper: get global option with fallback
	// ------------------------------------------------------------------

	private static function g( string $key, $default = '' ) {
		return get_option( $key, $default );
	}

	// ------------------------------------------------------------------
	// Title override
	// ------------------------------------------------------------------

	public static function filter_title( string $title ): string {
		if ( ! is_singular() ) return $title;
		$override = get_post_meta( get_the_ID(), 'echs_seo_title', true );
		return ( '' !== $override ) ? $override : $title;
	}

	// ------------------------------------------------------------------
	// SEO meta tags
	// ------------------------------------------------------------------

	public static function output_seo_meta(): void {
		if ( ! is_singular() ) return;

		$post_id = get_the_ID();

		// Meta description.
		$desc = get_post_meta( $post_id, 'echs_seo_description', true );
		if ( '' !== $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}

		// Canonical.
		$canonical = get_post_meta( $post_id, 'echs_canonical_url', true );
		if ( '' !== $canonical ) {
			echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
		}

		// Robots — always explicit; noindex/nofollow override the default index, follow.
		$noindex  = '1' === get_post_meta( $post_id, 'echs_noindex',  true );
		$nofollow = '1' === get_post_meta( $post_id, 'echs_nofollow', true );
		if ( $noindex || $nofollow ) {
			$robots = [];
			if ( $noindex )  $robots[] = 'noindex';
			if ( $nofollow ) $robots[] = 'nofollow';
		} else {
			$robots = [ 'index', 'follow' ];
		}
		echo '<meta name="robots" content="' . esc_attr( implode( ', ', $robots ) ) . '">' . "\n";

		// Resolved SEO title (used as fallback for OG/Twitter when synced).
		$seo_title = get_post_meta( $post_id, 'echs_seo_title', true ) ?: get_the_title( $post_id );

		// Resolve og:image: per-page custom → featured image → global logo.
		$og_synced = ( '0' !== get_post_meta( $post_id, 'echs_og_same_as_meta', true ) );
		$og_image  = $og_synced ? '' : get_post_meta( $post_id, 'echs_og_image', true );
		if ( '' === $og_image ) {
			$thumb_id = get_post_thumbnail_id( $post_id );
			if ( $thumb_id ) {
				$img = wp_get_attachment_image_src( $thumb_id, 'large' );
				if ( $img ) $og_image = $img[0];
			}
		}
		if ( '' === $og_image ) {
			$og_image = self::g( 'echs_default_og_image' );
		}

		// Open Graph.
		$og_fields = [
			'og:title'       => $og_synced ? $seo_title : ( get_post_meta( $post_id, 'echs_og_title', true )       ?: $seo_title ),
			'og:description' => $og_synced ? $desc      : ( get_post_meta( $post_id, 'echs_og_description', true ) ?: $desc ),
			'og:url'         => get_permalink( $post_id ),
			'og:type'        => 'website',
		];
		if ( '' !== $og_image ) {
			$og_fields['og:image'] = $og_image;
		}
		foreach ( $og_fields as $prop => $content ) {
			if ( '' !== $content ) {
				echo '<meta property="' . esc_attr( $prop ) . '" content="' . esc_attr( $content ) . '">' . "\n";
			}
		}

		// Resolve twitter:image: per-page custom → same fallback chain as OG.
		$tw_synced = ( '0' !== get_post_meta( $post_id, 'echs_twitter_same_as_meta', true ) );
		$tw_title  = $tw_synced ? $seo_title : ( get_post_meta( $post_id, 'echs_twitter_title', true )       ?: $seo_title );
		$tw_desc   = $tw_synced ? $desc      : ( get_post_meta( $post_id, 'echs_twitter_description', true ) ?: $desc );
		$tw_image  = $tw_synced ? $og_image  : ( get_post_meta( $post_id, 'echs_twitter_image', true ) ?: $og_image );

		// Twitter (X) card.
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		if ( '' !== $tw_title ) echo '<meta name="twitter:title" content="' . esc_attr( $tw_title ) . '">' . "\n";
		if ( '' !== $tw_desc )  echo '<meta name="twitter:description" content="' . esc_attr( $tw_desc ) . '">' . "\n";
		if ( '' !== $tw_image ) echo '<meta name="twitter:image" content="' . esc_url( $tw_image ) . '">' . "\n";
	}

	// ------------------------------------------------------------------
	// Schema JSON-LD output
	// ------------------------------------------------------------------

	public static function output_schema(): void {
		$schemas        = [];
		$emitted_types  = [];

		$is_front      = is_front_page();
		$is_singular   = is_singular();
		$post_id       = $is_singular ? get_the_ID() : 0;
		$enabled_types = $post_id ? ( get_post_meta( $post_id, 'echs_schema_enabled_types', true ) ?: [] ) : [];

		// --- Sitewide: Organization + WebSite on every page ---
		// Gives AI crawlers and Google a consistent entity anchor across the entire site.
		$schemas[]       = self::build_organization();
		$emitted_types[] = 'Organization';

		$schemas[]       = self::build_website();
		$emitted_types[] = 'WebSite';

		// --- LocalBusiness: every singular page by default ---
		// Ensures address, phone, and service area appear in SERPs on all pages.
		if ( $is_front || ( $is_singular && $post_id ) ) {
			$schemas[]       = self::build_local_business( $post_id );
			$emitted_types[] = 'LocalBusiness';
		}

		// --- Person: output for each configured team member (sitewide) ---
		// Allows AI to associate names/titles/LinkedIn with the business entity.
		$team_members = self::g( 'echs_team_members', [] );
		foreach ( (array) $team_members as $member ) {
			if ( ! empty( $member['name'] ) ) {
				$schemas[] = self::build_person( $member );
			}
		}

		if ( $is_singular && $post_id ) {

			// BreadcrumbList — auto on all non-homepage singular pages.
			if ( ! $is_front && ! in_array( 'BreadcrumbList', $emitted_types, true ) ) {
				$s = self::build_breadcrumb( $post_id );
				if ( $s ) {
					$schemas[]       = $s;
					$emitted_types[] = 'BreadcrumbList';
				}
			}

			// Service.
			if ( in_array( 'Service', $enabled_types, true ) && ! in_array( 'Service', $emitted_types, true ) ) {
				$s = self::build_service( $post_id );
				if ( $s ) {
					$schemas[]       = $s;
					$emitted_types[] = 'Service';
				}
			}

			// Product.
			if ( in_array( 'Product', $enabled_types, true ) && ! in_array( 'Product', $emitted_types, true ) ) {
				$s = self::build_product( $post_id );
				if ( $s ) {
					$schemas[]       = $s;
					$emitted_types[] = 'Product';
				}
			}

			// FAQPage.
			if ( in_array( 'FAQPage', $enabled_types, true ) && ! in_array( 'FAQPage', $emitted_types, true ) ) {
				$s = self::build_faq( $post_id );
				if ( $s ) {
					$schemas[]       = $s;
					$emitted_types[] = 'FAQPage';
				}
			}

			// HowTo.
			if ( in_array( 'HowTo', $enabled_types, true ) && ! in_array( 'HowTo', $emitted_types, true ) ) {
				$s = self::build_howto( $post_id );
				if ( $s ) {
					$schemas[]       = $s;
					$emitted_types[] = 'HowTo';
				}
			}

			// Review.
			if ( in_array( 'Review', $enabled_types, true ) && ! in_array( 'Review', $emitted_types, true ) ) {
				$s = self::build_review( $post_id );
				if ( $s ) {
					$schemas[]       = $s;
					$emitted_types[] = 'Review';
				}
			}

			// WebPage — always output on singular pages (auto-detects AboutPage, ContactPage).
			if ( ! in_array( 'WebPage', $emitted_types, true ) ) {
				$schemas[]       = self::build_webpage( $post_id );
				$emitted_types[] = 'WebPage';
			}
		}

		// Product taxonomy / category archives (WooCommerce ItemList).
		if ( is_tax( 'product_cat' ) || is_post_type_archive( 'product' ) ) {
			$s = self::build_product_item_list();
			if ( $s ) $schemas[] = $s;
		}

		foreach ( $schemas as $schema ) {
			if ( ! empty( $schema ) ) {
				echo '<script type="application/ld+json">' . "\n";
				echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
				echo "\n</script>\n";
			}
		}
	}

	// ------------------------------------------------------------------
	// Schema builders
	// ------------------------------------------------------------------

	private static function get_logo_url(): string {
		$logo = self::g( 'echs_logo_url' );
		if ( '' !== $logo ) return $logo;

		// Auto-pull from WP site logo.
		$logo_id = get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$img = wp_get_attachment_image_src( $logo_id, 'full' );
			if ( $img ) return $img[0];
		}
		return '';
	}

	private static function get_address(): array {
		$street = self::g( 'echs_street' );
		if ( '' === $street ) return [];

		return [
			'@type'           => 'PostalAddress',
			'streetAddress'   => $street,
			'addressLocality' => self::g( 'echs_city' ),
			'addressRegion'   => self::g( 'echs_state' ),
			'postalCode'      => self::g( 'echs_zip' ),
			'addressCountry'  => 'US',
		];
	}

	private static function get_secondary_addresses(): array {
		$locations = self::g( 'echs_secondary_locations', [] );
		$addresses = [];
		foreach ( (array) $locations as $loc ) {
			if ( ! empty( $loc['street'] ) ) {
				$addresses[] = [
					'@type'           => 'PostalAddress',
					'streetAddress'   => $loc['street'],
					'addressLocality' => $loc['city']  ?? '',
					'addressRegion'   => $loc['state'] ?? '',
					'postalCode'      => $loc['zip']   ?? '',
					'addressCountry'  => 'US',
				];
			}
		}
		return $addresses;
	}

	private static function get_opening_hours(): array {
		$hours  = self::g( 'echs_hours', [] );
		$specs  = [];
		$day_map = [
			'Monday'    => 'Monday',
			'Tuesday'   => 'Tuesday',
			'Wednesday' => 'Wednesday',
			'Thursday'  => 'Thursday',
			'Friday'    => 'Friday',
			'Saturday'  => 'Saturday',
			'Sunday'    => 'Sunday',
		];
		foreach ( $day_map as $key => $schema_day ) {
			if ( ! empty( $hours[ $key ]['open'] ) && ! empty( $hours[ $key ]['close'] ) ) {
				$specs[] = [
					'@type'     => 'OpeningHoursSpecification',
					'dayOfWeek' => 'https://schema.org/' . $schema_day,
					'opens'     => $hours[ $key ]['open'],
					'closes'    => $hours[ $key ]['close'],
				];
			}
		}
		return $specs;
	}

	private static function build_local_business( int $post_id = 0 ): array {
		$type        = self::g( 'echs_schema_type', 'HomeAndConstructionBusiness' );
		$description = $post_id ? ( get_post_meta( $post_id, 'echs_lb_description', true ) ?: self::g( 'echs_slogan' ) ) : self::g( 'echs_slogan' );
		$phone       = $post_id ? ( get_post_meta( $post_id, 'echs_lb_phone', true ) ?: self::g( 'echs_phone' ) ) : self::g( 'echs_phone' );

		$schema = [
			'@context' => 'https://schema.org',
			'@type'    => $type,
			'name'     => self::g( 'echs_business_name' ),
			'url'      => self::g( 'echs_primary_url', home_url() ),
		];

		if ( '' !== $description )               $schema['description']  = $description;
		if ( '' !== $phone )                     $schema['telephone']    = $phone;
		if ( '' !== self::g( 'echs_email' ) )     $schema['email']        = self::g( 'echs_email' );
		if ( '' !== self::g( 'echs_price_range' ) ) $schema['priceRange'] = self::g( 'echs_price_range' );
		if ( '' !== self::g( 'echs_founded_year' ) ) $schema['foundingDate'] = self::g( 'echs_founded_year' );

		// Logo.
		$logo_url = self::get_logo_url();
		if ( '' !== $logo_url ) {
			$schema['logo'] = [ '@type' => 'ImageObject', 'url' => $logo_url ];
		}

		// Address(es) — primary first, then any secondary locations.
		$primary     = self::get_address();
		$secondaries = self::get_secondary_addresses();
		if ( ! empty( $primary ) ) {
			$all_addresses     = array_merge( [ $primary ], $secondaries );
			$schema['address'] = count( $all_addresses ) === 1 ? $all_addresses[0] : $all_addresses;
		}

		// Geo.
		$lat = self::g( 'echs_latitude' );
		$lng = self::g( 'echs_longitude' );
		if ( '' !== $lat && '' !== $lng ) {
			$schema['geo'] = [
				'@type'     => 'GeoCoordinates',
				'latitude'  => (float) $lat,
				'longitude' => (float) $lng,
			];
		}

		// Service areas.
		$areas = self::g( 'echs_service_areas', [] );
		if ( ! empty( $areas ) ) {
			$schema['areaServed'] = array_map( fn( $a ) => [ '@type' => 'City', 'name' => $a ], $areas );
		}

		// Hours.
		$hours = self::get_opening_hours();
		if ( ! empty( $hours ) ) $schema['openingHoursSpecification'] = $hours;

		// sameAs.
		$same_as = self::g( 'echs_same_as', [] );
		if ( ! empty( $same_as ) ) $schema['sameAs'] = $same_as;

		// Aggregate rating.
		$rating_val   = self::g( 'echs_rating_value' );
		$rating_count = self::g( 'echs_rating_count' );
		if ( '' !== $rating_val && '' !== $rating_count ) {
			$schema['aggregateRating'] = [
				'@type'       => 'AggregateRating',
				'ratingValue' => (float) $rating_val,
				'reviewCount' => (int) $rating_count,
			];
		}

		// Legal name.
		$legal = self::g( 'echs_legal_name' );
		if ( '' !== $legal ) $schema['legalName'] = $legal;

		return $schema;
	}

	private static function build_organization(): array {
		$schema = [
			'@context' => 'https://schema.org',
			'@type'    => 'Organization',
			'name'     => self::g( 'echs_business_name' ),
			'url'      => self::g( 'echs_primary_url', home_url() ),
		];

		$logo_url = self::get_logo_url();
		if ( '' !== $logo_url ) {
			$schema['logo'] = [ '@type' => 'ImageObject', 'url' => $logo_url ];
		}

		$same_as = self::g( 'echs_same_as', [] );
		if ( ! empty( $same_as ) ) $schema['sameAs'] = $same_as;

		$slogan = self::g( 'echs_slogan' );
		if ( '' !== $slogan ) $schema['slogan'] = $slogan;

		return $schema;
	}

	private static function build_website(): array {
		return [
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'name'            => self::g( 'echs_business_name' ),
			'url'             => home_url(),
			'potentialAction' => [
				'@type'       => 'SearchAction',
				'target'      => [
					'@type'       => 'EntryPoint',
					'urlTemplate' => home_url( '/?s={search_term_string}' ),
				],
				'query-input' => 'required name=search_term_string',
			],
		];
	}

	/**
	 * Build a Person schema block for a team member.
	 *
	 * Stored in global option echs_team_members as an array of:
	 *   [ 'name' => '', 'job_title' => '', 'linkedin' => '', 'image' => '' ]
	 */
	private static function build_person( array $member ): array {
		$schema = [
			'@context' => 'https://schema.org',
			'@type'    => 'Person',
			'name'     => $member['name'],
			'worksFor' => [
				'@type' => 'Organization',
				'name'  => self::g( 'echs_business_name' ),
			],
		];

		if ( ! empty( $member['job_title'] ) ) $schema['jobTitle'] = $member['job_title'];
		if ( ! empty( $member['image'] ) )     $schema['image']    = $member['image'];

		// LinkedIn or other profile URL → sameAs.
		if ( ! empty( $member['linkedin'] ) ) {
			$schema['sameAs'] = [ $member['linkedin'] ];
		}

		return $schema;
	}

	private static function build_service( int $post_id ): ?array {
		$name = get_post_meta( $post_id, 'echs_service_name', true ) ?: get_the_title( $post_id );
		if ( '' === $name ) return null;

		$schema = [
			'@context'    => 'https://schema.org',
			'@type'       => 'Service',
			'name'        => $name,
			'provider'    => [
				'@type' => self::g( 'echs_schema_type', 'LocalBusiness' ),
				'name'  => self::g( 'echs_business_name' ),
			],
		];

		$desc = get_post_meta( $post_id, 'echs_service_description', true );
		if ( '' !== $desc ) $schema['description'] = $desc;

		$svc_type = get_post_meta( $post_id, 'echs_service_type', true );
		if ( '' !== $svc_type ) $schema['serviceType'] = $svc_type;

		$area_override = get_post_meta( $post_id, 'echs_service_area_override', true );
		if ( '' !== $area_override ) {
			$schema['areaServed'] = $area_override;
		} else {
			$areas = self::g( 'echs_service_areas', [] );
			if ( ! empty( $areas ) ) {
				$schema['areaServed'] = array_map( fn( $a ) => [ '@type' => 'City', 'name' => $a ], $areas );
			}
		}

		return $schema;
	}

	private static function build_product( int $post_id ): ?array {
		$name = get_post_meta( $post_id, 'echs_product_name', true ) ?: get_the_title( $post_id );

		$schema = [
			'@context' => 'https://schema.org',
			'@type'    => 'Product',
			'name'     => $name,
		];

		$desc = get_post_meta( $post_id, 'echs_product_description', true );
		if ( '' !== $desc ) $schema['description'] = $desc;

		$brand = get_post_meta( $post_id, 'echs_product_brand', true );
		if ( '' !== $brand ) $schema['brand'] = [ '@type' => 'Brand', 'name' => $brand ];

		$price        = get_post_meta( $post_id, 'echs_product_price', true );
		$currency     = get_post_meta( $post_id, 'echs_product_currency', true ) ?: 'USD';
		$availability = get_post_meta( $post_id, 'echs_product_availability', true ) ?: 'https://schema.org/InStock';

		if ( '' !== $price ) {
			$schema['offers'] = [
				'@type'         => 'Offer',
				'price'         => $price,
				'priceCurrency' => $currency,
				'availability'  => $availability,
			];
		}

		$warranty = get_post_meta( $post_id, 'echs_product_warranty', true );
		if ( '' !== $warranty ) {
			$schema['warranty'] = [ '@type' => 'WarrantyPromise', 'description' => $warranty ];
		}

		return $schema;
	}

	private static function build_faq( int $post_id ): ?array {
		$entries = get_post_meta( $post_id, 'echs_faq_entries', true ) ?: [];
		if ( empty( $entries ) ) return null;

		$items = [];
		foreach ( $entries as $faq ) {
			if ( '' !== $faq['question'] ) {
				$items[] = [
					'@type'          => 'Question',
					'name'           => $faq['question'],
					'acceptedAnswer' => [
						'@type' => 'Answer',
						'text'  => $faq['answer'],
					],
				];
			}
		}

		if ( empty( $items ) ) return null;

		return [
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $items,
		];
	}

	private static function build_breadcrumb( int $post_id ): ?array {
		$post = get_post( $post_id );
		if ( ! $post ) return null;

		$items   = [];
		$pos     = 1;
		$items[] = [
			'@type'    => 'ListItem',
			'position' => $pos++,
			'name'     => get_bloginfo( 'name' ),
			'item'     => home_url(),
		];

		// Walk up the page hierarchy.
		$ancestors = array_reverse( get_post_ancestors( $post_id ) );
		foreach ( $ancestors as $ancestor_id ) {
			$items[] = [
				'@type'    => 'ListItem',
				'position' => $pos++,
				'name'     => get_the_title( $ancestor_id ),
				'item'     => get_permalink( $ancestor_id ),
			];
		}

		$items[] = [
			'@type'    => 'ListItem',
			'position' => $pos,
			'name'     => get_the_title( $post_id ),
			'item'     => get_permalink( $post_id ),
		];

		return [
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $items,
		];
	}

	private static function build_webpage( int $post_id ): array {
		$type = 'WebPage';
		$slug = get_post_field( 'post_name', $post_id );

		if ( str_contains( $slug, 'about' ) )   $type = 'AboutPage';
		if ( str_contains( $slug, 'contact' ) ) $type = 'ContactPage';

		return [
			'@context'    => 'https://schema.org',
			'@type'       => $type,
			'name'        => get_the_title( $post_id ),
			'url'         => get_permalink( $post_id ),
			'description' => get_post_meta( $post_id, 'echs_seo_description', true ),
		];
	}

	private static function build_howto( int $post_id ): ?array {
		$steps = get_post_meta( $post_id, 'echs_howto_steps', true ) ?: [];
		if ( empty( $steps ) ) return null;

		$name = get_post_meta( $post_id, 'echs_howto_name', true ) ?: get_the_title( $post_id );

		$schema = [
			'@context' => 'https://schema.org',
			'@type'    => 'HowTo',
			'name'     => $name,
		];

		$desc = get_post_meta( $post_id, 'echs_howto_description', true );
		if ( '' !== $desc ) $schema['description'] = $desc;

		$total_time = get_post_meta( $post_id, 'echs_howto_total_time', true );
		if ( '' !== $total_time ) $schema['totalTime'] = $total_time;

		$schema['step'] = array_map( function ( array $step, int $i ): array {
			return [
				'@type'    => 'HowToStep',
				'position' => $i + 1,
				'name'     => $step['name'],
				'text'     => $step['text'],
			];
		}, $steps, array_keys( $steps ) );

		return $schema;
	}

	private static function build_review( int $post_id ): ?array {
		$item_name = get_post_meta( $post_id, 'echs_review_item_name', true );
		$author    = get_post_meta( $post_id, 'echs_review_author', true );
		if ( '' === $item_name || '' === $author ) return null;

		$rating = get_post_meta( $post_id, 'echs_review_rating', true ) ?: '5';
		$schema = [
			'@context'     => 'https://schema.org',
			'@type'        => 'Review',
			'itemReviewed' => [
				'@type' => 'Thing',
				'name'  => $item_name,
			],
			'author'       => [
				'@type' => 'Person',
				'name'  => $author,
			],
			'reviewRating' => [
				'@type'       => 'Rating',
				'ratingValue' => (float) $rating,
				'bestRating'  => 5,
				'worstRating' => 1,
			],
		];

		$name = get_post_meta( $post_id, 'echs_review_name', true );
		if ( '' !== $name ) $schema['name'] = $name;

		$body = get_post_meta( $post_id, 'echs_review_body', true );
		if ( '' !== $body ) $schema['reviewBody'] = $body;

		return $schema;
	}

	private static function build_product_item_list(): ?array {
		if ( ! class_exists( 'WooCommerce' ) ) return null;

		$products = wc_get_products( [ 'limit' => 20, 'status' => 'publish' ] );
		if ( empty( $products ) ) return null;

		$items = [];
		foreach ( $products as $i => $product ) {
			$items[] = [
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'url'      => get_permalink( $product->get_id() ),
			];
		}

		return [
			'@context'        => 'https://schema.org',
			'@type'           => 'ItemList',
			'itemListElement' => $items,
		];
	}
}
